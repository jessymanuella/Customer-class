package mediaRentalManager;

import java.util.ArrayList;

/**
 * This class allows you to compare methods with each other. Also, creates an ArrayList of rented and queue.
 */


public class Customer implements Comparable<Customer> {

	private String name;
	private String address;
	private String plan;
	private ArrayList<String> rented = new ArrayList<String>();
	private ArrayList<String> queue = new ArrayList<String>();
	
	/**
	 * This method returns the instance of name, address, and plan.
	 * @param name
	 * @param address
	 * @param plan
	 */

	public Customer(String name, String address, String plan) {
		this.name = name;
		this.address = address;
		this.plan = plan;
	}
	
	/**
	 * This method returns the name of customers.
	 * @return
	 */

	public String getName() {
		return name;
	}
	
	/**
	 * This method returns the address of customers.
	 * @return
	 */

	public String getAddress() {
		return address;
	}
	
	/**
	 * This method returns the plan of the customers.
	 * @return
	 */

	public String getPlan() {
		return plan;
	}
	
	/**
	 * This method returns an arrayList of queue.
	 * @return
	 */

	public ArrayList<String> getQueue() {
		return queue;
	}
	
	/**
	 * This method returns an ArrayList of rented.
	 * @return
	 */

	public ArrayList<String> getRented() {
		return rented;
	}
	
	/**
	 * This methods allows the string representation of the object. It will allow you to print the customer's name, address, plan, rented and queue.
	 */

	public String toString() {
		return "Name: " + this.name + ", Address: " + this.address + ", Plan: " + this.plan + "\n" + "Rented: "
				+ this.rented + "\n" + "Queue: " + this.queue + "\n";
	}
	
	/**
	 * This method adds the mediaTitle to the queue.
	 * @param mediaTitle
	 */

	public void addMediaTitle(String mediaTitle) {
		queue.add(mediaTitle);

	}
	
	/**
	 * This method adds the mediaTitle to the rented.
	 * @param mediaTitle
	 */

	public void addToRented(String mediaTitle) {
		rented.add(mediaTitle);
	}
	
	/**
	 * This method removes the mediaTitle from the queue.
	 * @param mediaTitle
	 */

	public void removeMediaTitle(String mediaTitle) {
		queue.remove(mediaTitle);
	}
	
	/**
	 * This method removes the MediaTitle from the rented.
	 * @param mediaTitle
	 */

	public void removeRented(String mediaTitle) {
		rented.remove(mediaTitle);
	}
	
	/**
	 * This method checks to see if the queue contains a mediaTitle. If it does it will return true, if it doesn't it will return false.
	 * @param mediaTitle
	 * @return
	 */

	public boolean isInQueue(String mediaTitle) {

		if (queue.contains(mediaTitle)) {
			return true;
		}
		return false;
	}
	
	/**
	 * This method checks to see if the rented contains a mediaTitle. If it does it will return true, if it doesn't it will return false.
	 * @param mediaTitle
	 * @return
	 */

	public boolean isRented(String mediaTitle) {
		if (rented.contains(mediaTitle)) {
			return true;
		}
		return false;
	}
	
	/**
	 * This method allows you to compare customer to other methods.
	 */

	@Override
	public int compareTo(Customer customer) {
		return this.name.compareTo(customer.name);
	}

}
